# Berkeley Algorithm

ASSIGNMENT 4

## Files :

-   BerkeleyAlgorithm.java

## Terminal 1

```
javac BerkeleyAlgorithm.java
```

```
java BerkeleyAlgorithm
```
